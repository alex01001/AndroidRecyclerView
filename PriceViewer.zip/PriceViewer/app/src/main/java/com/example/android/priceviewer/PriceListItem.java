package com.example.android.priceviewer;

/**
 * Created by ganina on 11/29/2017.
 */

public class PriceListItem {
    int img;
    String date;
    String price;
    String change;

}
